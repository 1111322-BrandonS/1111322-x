﻿namespace L10_1111322
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.inputDescripcion = new System.Windows.Forms.RichTextBox();
            this.inputPrecio = new System.Windows.Forms.NumericUpDown();
            this.inputModelo = new System.Windows.Forms.NumericUpDown();
            this.inputMarca = new System.Windows.Forms.TextBox();
            this.botonCargarDatos = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.outputPrecioFinal = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.botonCalcularPrecio = new System.Windows.Forms.Button();
            this.inputIVA = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.outputDescripcion = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.outputPrecio = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.outputModelo = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.outputMarca = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.botonActualizar = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(844, 506);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.inputDescripcion);
            this.tabPage1.Controls.Add(this.inputPrecio);
            this.tabPage1.Controls.Add(this.inputModelo);
            this.tabPage1.Controls.Add(this.inputMarca);
            this.tabPage1.Controls.Add(this.botonCargarDatos);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(836, 477);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // inputDescripcion
            // 
            this.inputDescripcion.Location = new System.Drawing.Point(107, 261);
            this.inputDescripcion.Name = "inputDescripcion";
            this.inputDescripcion.Size = new System.Drawing.Size(585, 114);
            this.inputDescripcion.TabIndex = 9;
            this.inputDescripcion.Text = "";
            // 
            // inputPrecio
            // 
            this.inputPrecio.DecimalPlaces = 2;
            this.inputPrecio.Increment = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            this.inputPrecio.Location = new System.Drawing.Point(107, 180);
            this.inputPrecio.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.inputPrecio.Name = "inputPrecio";
            this.inputPrecio.Size = new System.Drawing.Size(585, 22);
            this.inputPrecio.TabIndex = 8;
            this.inputPrecio.ThousandsSeparator = true;
            // 
            // inputModelo
            // 
            this.inputModelo.Location = new System.Drawing.Point(107, 128);
            this.inputModelo.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.inputModelo.Minimum = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            this.inputModelo.Name = "inputModelo";
            this.inputModelo.Size = new System.Drawing.Size(585, 22);
            this.inputModelo.TabIndex = 7;
            this.inputModelo.ThousandsSeparator = true;
            this.inputModelo.Value = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            // 
            // inputMarca
            // 
            this.inputMarca.Location = new System.Drawing.Point(107, 78);
            this.inputMarca.Name = "inputMarca";
            this.inputMarca.Size = new System.Drawing.Size(585, 22);
            this.inputMarca.TabIndex = 6;
            // 
            // botonCargarDatos
            // 
            this.botonCargarDatos.Location = new System.Drawing.Point(282, 381);
            this.botonCargarDatos.Name = "botonCargarDatos";
            this.botonCargarDatos.Size = new System.Drawing.Size(227, 62);
            this.botonCargarDatos.TabIndex = 5;
            this.botonCargarDatos.Text = "Cargar Datos";
            this.botonCargarDatos.UseVisualStyleBackColor = true;
            this.botonCargarDatos.Click += new System.EventHandler(this.botonCargarDatos_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Descripcion";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Precio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Modelo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Marca";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(29, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Carros";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.outputPrecioFinal);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.botonCalcularPrecio);
            this.tabPage2.Controls.Add(this.inputIVA);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.outputDescripcion);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.outputPrecio);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.outputModelo);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.outputMarca);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.botonActualizar);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(836, 477);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ver Datos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // outputPrecioFinal
            // 
            this.outputPrecioFinal.AutoSize = true;
            this.outputPrecioFinal.Location = new System.Drawing.Point(147, 421);
            this.outputPrecioFinal.Name = "outputPrecioFinal";
            this.outputPrecioFinal.Size = new System.Drawing.Size(78, 16);
            this.outputPrecioFinal.TabIndex = 13;
            this.outputPrecioFinal.Text = "Precio Final";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(43, 421);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 16);
            this.label15.TabIndex = 12;
            this.label15.Text = "Precio Final";
            // 
            // botonCalcularPrecio
            // 
            this.botonCalcularPrecio.Location = new System.Drawing.Point(144, 362);
            this.botonCalcularPrecio.Name = "botonCalcularPrecio";
            this.botonCalcularPrecio.Size = new System.Drawing.Size(123, 45);
            this.botonCalcularPrecio.TabIndex = 11;
            this.botonCalcularPrecio.Text = "Calcular Precio Final";
            this.botonCalcularPrecio.UseVisualStyleBackColor = true;
            // 
            // inputIVA
            // 
            this.inputIVA.DecimalPlaces = 2;
            this.inputIVA.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.inputIVA.Location = new System.Drawing.Point(147, 318);
            this.inputIVA.Name = "inputIVA";
            this.inputIVA.Size = new System.Drawing.Size(120, 22);
            this.inputIVA.TabIndex = 10;
            this.inputIVA.ThousandsSeparator = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 325);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 16);
            this.label14.TabIndex = 9;
            this.label14.Text = "IVA";
            // 
            // outputDescripcion
            // 
            this.outputDescripcion.AutoSize = true;
            this.outputDescripcion.Location = new System.Drawing.Point(144, 271);
            this.outputDescripcion.Name = "outputDescripcion";
            this.outputDescripcion.Size = new System.Drawing.Size(79, 16);
            this.outputDescripcion.TabIndex = 8;
            this.outputDescripcion.Text = "Descripcion";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 272);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Descripcion";
            // 
            // outputPrecio
            // 
            this.outputPrecio.AutoSize = true;
            this.outputPrecio.Location = new System.Drawing.Point(144, 225);
            this.outputPrecio.Name = "outputPrecio";
            this.outputPrecio.Size = new System.Drawing.Size(46, 16);
            this.outputPrecio.TabIndex = 6;
            this.outputPrecio.Text = "Precio";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 225);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 16);
            this.label10.TabIndex = 5;
            this.label10.Text = "Precio";
            // 
            // outputModelo
            // 
            this.outputModelo.AutoSize = true;
            this.outputModelo.Location = new System.Drawing.Point(144, 173);
            this.outputModelo.Name = "outputModelo";
            this.outputModelo.Size = new System.Drawing.Size(53, 16);
            this.outputModelo.TabIndex = 4;
            this.outputModelo.Text = "Modelo";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 16);
            this.label8.TabIndex = 3;
            this.label8.Text = "Modelo";
            // 
            // outputMarca
            // 
            this.outputMarca.AutoSize = true;
            this.outputMarca.Location = new System.Drawing.Point(141, 125);
            this.outputMarca.Name = "outputMarca";
            this.outputMarca.Size = new System.Drawing.Size(45, 16);
            this.outputMarca.TabIndex = 2;
            this.outputMarca.Text = "Marca";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Marca";
            // 
            // botonActualizar
            // 
            this.botonActualizar.Location = new System.Drawing.Point(173, 23);
            this.botonActualizar.Name = "botonActualizar";
            this.botonActualizar.Size = new System.Drawing.Size(490, 78);
            this.botonActualizar.TabIndex = 0;
            this.botonActualizar.Text = "Refrescar";
            this.botonActualizar.UseVisualStyleBackColor = true;
            this.botonActualizar.Click += new System.EventHandler(this.btonActualizar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 530);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputModelo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.inputIVA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.RichTextBox inputDescripcion;
        private System.Windows.Forms.NumericUpDown inputPrecio;
        private System.Windows.Forms.NumericUpDown inputModelo;
        private System.Windows.Forms.TextBox inputMarca;
        private System.Windows.Forms.Button botonCargarDatos;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label outputPrecioFinal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button botonCalcularPrecio;
        private System.Windows.Forms.NumericUpDown inputIVA;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label outputDescripcion;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label outputPrecio;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label outputModelo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label outputMarca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button botonActualizar;
    }
}

