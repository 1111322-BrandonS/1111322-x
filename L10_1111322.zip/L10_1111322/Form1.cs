﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L10_1111322
{
    public partial class Form1 : Form
    {
        Carro nuevoCarro = new Carro();

        public Form1()
        {
            InitializeComponent();
        }

        private void botonCargarDatos_Click(object sender, EventArgs e)
        {
        

            string marca = inputMarca.Text;
            int modelo = (int)inputModelo.Value;
            double precio = (double)inputPrecio.Value;
            string descripcion = inputDescripcion.Text;

            nuevoCarro.SetMarca(marca);
            nuevoCarro.SetPrecio(precio);
            nuevoCarro.SetDescripcion(descripcion);
            nuevoCarro.SetModelo(modelo);
        }

        private void btonActualizar_Click(object sender, EventArgs e)
        {
            outputMarca.Text = nuevoCarro.LeerMarca();
            outputDescripcion.Text = nuevoCarro.LeerDescripcion();
            outputPrecio.Text = nuevoCarro.LeerPrecio().ToString();
            outputModelo.Text = nuevoCarro.LeerModelo().ToString();
        }
    }
}
