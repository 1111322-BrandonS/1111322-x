﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_1111322
{
    internal class Carro
    {
        private string Marca = "";
        private int Modelo = 0;
        private double Precio = 0;
        private string Descripcion = "";

        public void SetMarca(string marca)
        {
            if (marca != "")
            {
                this.Marca = marca;
            }
        }

        public void SetModelo(int modelo)
        {
            this.Modelo = modelo;
        }

        public void SetPrecio(double precio)
        {
            this.Precio = precio;
        }

        public void SetDescripcion(string desc)
        {
            this.Descripcion = desc;
        }

        public string LeerMarca ()
        {
            return this.Marca;
        }

        public int LeerModelo()
        {
            return this.Modelo;
        }
        public double LeerPrecio()
        {
            return this.Precio;
        }
        public string LeerDescripcion()
        {
            return this.Descripcion;
        }
    }
}
